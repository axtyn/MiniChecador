<?php
	include('config.php');
	$nombre	 	= $_POST['nombre'];
	$apellidos1 = $_POST['apellidos1'];
	$apellidos2 = $_POST['apellidos2'];
	$email      = $_POST['email'];
	
	$sql = "INSERT INTO alumno (nombre,apellido_paterno,apellido_materno,correo) VALUES ('".$nombre."','".$apellidos1."','".$apellidos2."','".$email."')";
	mysql_query($sql,$conexion);
	echo '<center><img src="imagenes/correcto.gif"/>Informacion Almacenada Correctamente.</center>';
 ?>