<?php
	include('config.php');
	$idalumno 		= $_POST['id'];
	$idcurso  		= $_POST['curso'];
	$fechainicial 	= $_POST['fechainicial'];
	$fechafinal		= $_POST['fechafinal'];
	
	$sql = "INSERT INTO rel_alumno_curso (idcurso,idalumno,fecha_inicio,fecha_fin) VALUES ('".$idcurso."','".$idalumno."','".$fechainicial."','".$fechafinal."')";

	mysql_query($sql,$conexion);
	echo '<center><img src="imagenes/correcto.gif"/>Informacion Almacenada Correctamente.</center>';

?>