<link href="css/MenuPrincipal.css" rel="stylesheet" type="text/css"/>

<?php
	    error_reporting(0);
		$Nivel = $_GET['Nivel'];
		if($Nivel==0){
		echo ' <ul id="navigation">';
		echo '<li><a href="Contenido.php?Nivel=0" target="admin" class="last">Inicio</a></li>';
		echo '<li><a href="Menu.php?Nivel=1">Catalogo Alumnos</a></li>';
		echo '<li><a href="Menu.php?Nivel=2">Catalogo Cursos</a></li>';
		echo '<li><a href="Menu.php?Nivel=3">Inscribir Alumnos a Otros Cursos</a></li>';
		echo '</ul>';
		}
		if($Nivel==1){
		echo ' <ul id="navigation">';
		echo '<li><a href="Menu.php?Nivel=0" class="last">Inicio</a></li>';
		echo '<li><a href="registraralumno.php" target="admin">Registrar Alumno</a></li>';
		echo '<li><a href="listalumnos.php" target="admin">Lista Alumnos</a></li>';
		
		echo '</ul>';
		}
		
		if($Nivel==2){
		echo ' <ul id="navigation">';
		echo '<li><a href="Menu.php?Nivel=0" class="last">Inicio</a></li>';
		echo '<li><a href="nuevocurso.php" target="admin">Registrar Curso</a></li>';
		echo '<li><a href="listacurso.php" target="admin">Lista Curso</a></li>';
		
		echo '</ul>';
		}
		
		if($Nivel==3){
		echo ' <ul id="navigation">';
		echo '<li><a href="Menu.php?Nivel=0" class="last">Inicio</a></li>';
		echo '<li><a href="listalumnoscurso.php" target="admin">Inscribir Alumnos a Otros Cursos</a></li>';
		
		echo '</ul>';
		}


 ?>
